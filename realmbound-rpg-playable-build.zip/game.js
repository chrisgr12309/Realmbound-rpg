'use strict';
const $=id=>document.getElementById(id), KEY='realmbound_save_v2';
const areas=[
['village','Beginner Village','🏘️',1,'Een veilige startplaats.',['forest']],
['forest','Beginner Forest','🌲',1,'Een groen woud vol zwakke monsters.',['village','kingdom']],
['kingdom','Human Kingdom','🏰',12,'De hoofdstad met koning en Adventurer Guild.',['forest','elf','caverns','harbor']],
['elf','Elven Area · World Tree','🌳',25,'Het eeuwenoude elfenwoud.',['kingdom','dragonTomb','ruins']],
['caverns','Crystal Caverns','💎',30,'Kristalgrotten met elementaire monsters.',['kingdom','ruins']],
['ruins','Ruined Kingdom','🏚️',40,'Een gevallen rijk vol oude wachters.',['caverns','elf','demon']],
['dragonTomb','Dragon Tomb','⛰️',50,'Een berg vol drakenhistorie.',['elf']],
['harbor','Royal Harbor','⚓',12,'De haven naar The Lost Isle.',['kingdom','isle']],
['isle','The Lost Isle','🏝️',55,'Een geheimzinnig eiland.',['harbor']],
['demon','Demon Realm','🔥',70,'Het rijk achter de tweede grens.',['ruins']]
];
const classes=[
['warrior','Warrior','⚔️',1,'Krachtige en gebalanceerde strijder',[['Power Strike',1,10],['Guard',3,14],['Whirlwind',7,20]]],
['mage','Mage','🔮',1,'Magische schade en mana',[['Fire Bolt',1,8],['Frost Nova',3,14],['Arcane Burst',7,22]]],
['archer','Archer','🏹',1,'Snelle aanvallen op afstand',[['Quick Shot',1,8],['Piercing Arrow',3,14],['Arrow Rain',7,20]]],
['assassin','Assassin','🗡️',1,'Snelheid en kritieke treffers',[['Shadow Cut',1,8],['Venom Edge',3,14],['Nightfall',7,20]]],
['berserker','Berserker','🪓',2,'Ontgrendelen via class quest',[['Rage',1,10],['Blood Roar',3,16],['Rupture',7,22]]],
['ninja','Ninja','🥷',2,'Ontgrendelen via class quest',[['Flash Step',1,9],['Smoke Blade',3,15],['Silent Storm',7,22]]],
['pirate','Pirate','🏴‍☠️',2,'Ontgrendelen via class quest',[['Cutlass',1,9],['Broadside',3,15],['Captain Fury',7,22]]],
['dragon','Dragon Slayer','🐉',3,'Speciale quest vanaf level 60',[['Dragon Fang',1,12],['Scale Breaker',3,18],['Wyrm Bane',7,26]]],
['divine','Divine Class','✨',4,'Angel-questlijn na de Demon King',[['Radiant Bolt',1,12],['Sanctuary',3,18],['Judgement',7,28]]]
];
const monsters=[
['slime','Forest Slime','🟢',1,26,4,12,5,'forest',30,['Gel','Small Potion']],
['wolf','Wild Wolf','🐺',3,40,6,18,7,'forest',30,['Wolf Pelt']],
['goblin','Goblin Scout','👺',6,65,9,28,10,'forest',30,['Goblin Ear','Iron Ore']],
['bandit','Road Bandit','🗡️',14,110,14,48,18,'kingdom',60,['Bandit Token','Iron Ore']],
['treant','Ancient Treant','🌲',27,250,24,110,42,'elf',120,['Ancient Bark']],
['golem','Crystal Golem','💎',32,350,30,145,55,'caverns',120,['Crystal Shard','Iron Ore']],
['knight','Ruined Knight','🛡️',43,520,39,220,80,'ruins',120,['Knight Sigil','Steel Ore']],
['wraith','Tomb Wraith','👻',55,780,48,320,120,'dragonTomb',180,['Ancient Scale']],
['guardian','Isle Guardian','🦀',58,900,55,390,150,'isle',180,['Tidal Core']],
['hound','Demon Hound','🐺',72,1250,68,520,190,'demon',120,['Demon Ash']]
];
const mainQuests=[
['The Village Elder','Praat met de Village Elder.','talk','elder'],['First Steps','Versla 3 Forest Slimes.','kill','slime',3],['A Wolf Problem','Versla 2 Wild Wolves.','kill','wolf',2],['Goblin Trouble','Versla 3 Goblin Scouts.','kill','goblin',3],['A Safer Road','Praat met de Merchant.','talk','merchant'],['Blacksmith Request','Verzamel 3 Iron Ore.','collect','Iron Ore',3],['Message to the Capital','Bereik Human Kingdom.','visit','kingdom'],['Guild Registration','Praat met de Guild Master.','talk','guild'],['Road Contract','Versla 4 Bandits.','kill','bandit',4],['King’s Audience','Praat met de King.','talk','king'],['Into the Elven Woods','Bereik Elven Area.','visit','elf'],['Roots of the World','Versla de Ancient Treant.','kill','treant'],['Crystal Rumours','Bereik Crystal Caverns.','visit','caverns'],['Shattered Core','Versla de Crystal Golem.','kill','golem'],['Echoes of Ruin','Bereik Ruined Kingdom.','visit','ruins'],['Fallen Guard','Versla 3 Ruined Knights.','kill','knight',3],['Mountain Script','Bereik Dragon Tomb.','visit','dragonTomb'],['Forgotten Scale','Verzamel 2 Ancient Scales.','collect','Ancient Scale',2],['Harbor Master','Praat met de Harbor Master.','talk','harbor'],['Sailing into Legend','Bereik The Lost Isle.','visit','isle'],['Tide Guardian','Versla de Isle Guardian.','kill','guardian'],['Demon Border','Bereik Demon Realm.','visit','demon'],['Hounds of Ash','Versla 5 Demon Hounds.','kill','hound',5],
...['Ash','Dread','Flame','Void'].map(x=>['Demon General: '+x,'Versla de '+x+' General.','boss','general'+x]),
['The Castle Key','Verzamel vier General Sigils.','collect','General Sigil',4],['The Demon King','Versla de Demon King.','boss','demonKing'],['The Hidden Revelation','Ontmoet de Angel Envoy.','talk','angel'],
...['Life Beast','Destruction Beast','Fire Beast','Water Beast'].map(x=>[x,'Versla de '+x+'.','boss',x]),
['The Angel Realm','Ontdek het verborgen Angel Realm.','special','angelRealm'],['Divine Trial','Voltooi de Angel-proef.','special','angelTrial'],
...['Aetherion','Chronos','Sylvaris','Vorthar'].map(x=>['Forgotten God: '+x,'Versla '+x+'.','boss',x]),
['Break the Four Seals','Verbreek de vier Divine Seals.','special','seals'],['The Divine Forge','Praat met de smid.','talk','forge'],['Divine Weapon','Maak een Divine Weapon.','craft','Divine Weapon'],['Creator’s Gate','Open de Creator’s Gate.','special','creatorGate'],['The Creator','Voltooi het laatste gevecht.','boss','creator'],['After the End','Praat met de Archivist.','talk','archivist'],
...Array.from({length:10},(_,i)=>['Forgotten Chronicle '+(i+1),'Voltooi een extra kroniek in de wereld.','special','chronicle'+i])
];
let S;
function fresh(){return {level:1,xp:0,gold:35,hp:100,maxhp:100,mp:45,maxmp:45,stats:{str:5,vit:5,agi:5,def:5,int:5},points:0,cls:'warrior',classLv:{warrior:1},unlocked:['warrior','mage','archer','assassin'],area:'village',bag:{'Small Potion':3,'Mana Potion':2,'Iron Ore':0},weapon:'Training Sword',armor:'Traveler Clothes',kills:{},completed:[],qi:0,progress:0,enemy:null,respawn:{},flags:{},log:['Je avontuur begint in Beginner Village.'],day:1,hour:8}}
function load(){try{return {...fresh(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return fresh()}} S=load();
let tab='world',skillReady=0;
function say(t){S.log.unshift(t);S.log=S.log.slice(0,5);$('log').textContent=S.log.join('\\n')}
function need(){return Math.floor(55+Math.pow(S.level,1.45)*18)}
function addXP(n){S.xp+=n;while(S.xp>=need()){S.xp-=need();S.level++;S.points+=3;S.maxhp+=8;S.maxmp+=4;S.hp=S.maxhp;S.mp=S.maxmp;S.classLv[S.cls]=(S.classLv[S.cls]||1)+1;say('Level omhoog! Level '+S.level+'. +3 statpunten.')} }
function addItem(n,c=1){S.bag[n]=(S.bag[n]||0)+c;questUpdate('collect',n,c)}
function q(){return mainQuests[S.qi]}
function questUpdate(type,target,n=1){let a=q();if(a&&a[2]===type&&a[3]===target){S.progress+=n;if(S.progress>=(a[4]||1))finishQuest()}}
function finishQuest(){let a=q();if(!a)return;S.completed.push(S.qi);S.gold+=35+S.qi*3;addXP(35+S.qi*10);say('Quest voltooid: '+a[0]);S.qi++;S.progress=0}
function area(){return areas.find(a=>a[0]===S.area)}
function travel(id){let a=areas.find(x=>x[0]===id);if(!a)return;if(S.level<a[3])return say('Je hebt level '+a[3]+' nodig.');if(!area()[5].includes(id))return say('Je kunt daar niet rechtstreeks heen reizen.');S.area=id;S.enemy=null;S.hour=(S.hour+1)%24;if(!S.hour)S.day++;questUpdate('visit',id);say('Je reist naar '+a[1]);render()}
function spawn(){let list=monsters.filter(m=>m[8]===S.area&&Date.now()>(S.respawn[m[0]]||0));if(!list.length)return say('Geen monsters beschikbaar. Ze keren later terug.');let m=list[Math.floor(Math.random()*list.length)];S.enemy={id:m[0],name:m[1],emoji:m[2],level:m[3],hp:m[4],max:m[4],damage:m[5],xp:m[6],gold:m[7],respawn:m[9],drops:m[10]};say(m[1]+' verschijnt!');render()}
function dmg(mult=1){return Math.max(2,Math.floor((S.stats.str*1.5+S.level+ (S.weapon==='Training Sword'?4:12))*mult))}
function enemyTurn(){if(!S.enemy)return;let hit=Math.max(1,S.enemy.damage-S.stats.def*.35);S.hp-=hit;say(S.enemy.name+' doet '+Math.floor(hit)+' schade.');if(S.hp<=0){S.hp=Math.ceil(S.maxhp*.4);S.mp=Math.ceil(S.maxmp*.4);S.gold=Math.max(0,S.gold-10);S.area='village';S.enemy=null;say('Je ontwaakt in Beginner Village.')}
}
function win(){let e=S.enemy;S.kills[e.id]=(S.kills[e.id]||0)+1;S.gold+=e.gold;addXP(e.xp);e.drops.forEach(x=>{if(Math.random()<.35){addItem(x);say('Gevonden: '+x)}});if(Math.random()<.075)addItem('Leather Armor');S.respawn[e.id]=Date.now()+e.respawn*1000;questUpdate('kill',e.id);say(e.name+' verslagen! +'+e.xp+' XP.');S.enemy=null}
function attack(mult=1){if(!S.enemy)return say('Zoek eerst een vijand.');S.enemy.hp-=dmg(mult);if(S.enemy.hp<=0)win();else enemyTurn();render()}
function skill(){if(!S.enemy)return say('Geen doelwit.');if(Date.now()<skillReady)return say('Skill is nog niet klaar.');let c=classes.find(x=>x[0]===S.cls),lv=S.classLv[S.cls]||1,available=c[5].filter(x=>x[1]<=lv),s=available[available.length-1];if(!s)return;let cost=s[2];if(S.mp<cost)return say('Niet genoeg mana.');S.mp-=cost;skillReady=Date.now()+12000;attackSkill(s[0]);}
function attackSkill(n){if(!S.enemy)return;let amount=dmg(1.8);S.enemy.hp-=amount;say(n+' doet '+amount+' schade.');if(S.enemy.hp<=0)win();else enemyTurn();render()}
function potion(n){if(!S.bag[n])return say('Je hebt die drank niet.');S.bag[n]--;if(n==='Mana Potion')S.mp=Math.min(S.maxmp,S.mp+35);else if(n==='Speed Potion')S.flags.speed=Date.now()+60000;else if(n==='Defense Potion')S.flags.def=Date.now()+60000;else S.hp=Math.min(S.maxhp,S.hp+45);say(n+' gebruikt.');render()}
function talk(id){let a=q();if(a&&a[2]==='talk'&&a[3]===id){finishQuest();render();return}let lines={elder:'De wereld wordt onrustig. Begin met de slimes in het bos.',merchant:'Ik verkoop drankjes en benodigdheden.',blacksmith:'Breng 3 Iron Ore om een Iron Sword te maken.',trainer:'Je klasse krijgt skills wanneer je met die klasse levelt.',healer:'Je HP en Mana zijn hersteld.',guild:'Voltooi contracten om je Guild-rang te verhogen.',king:'Bewijs je kracht voordat de grenzen opengaan.',harbor:'The Lost Isle ligt ver op zee.',angel:'De Demon King was niet het einde. Vier Divine Beasts bewaken de zegels.'};say(lines[id]||'Deze NPC heeft momenteel geen nieuwe opdracht.')}
function unlock(id){let c=classes.find(x=>x[0]===id);if(S.unlocked.includes(id)){S.cls=id;render();return}let ok=(id==='berserker'&&S.level>=15)||(id==='ninja'&&S.level>=20)||(id==='pirate'&&S.level>=25)||(id==='dragon'&&S.level>=60)||(id==='divine'&&S.flags.angel);if(ok){S.unlocked.push(id);S.cls=id;say(c[1]+' ontgrendeld!')}else say('Vergrendeld: voltooi de class quest en bereik het vereiste level.');render()}
function spend(k){if(S.points<1)return;S.points--;S.stats[k]++;if(k==='vit'){S.maxhp+=12;S.hp+=12}if(k==='int'){S.maxmp+=8;S.mp+=8}render()}
function shop(){let n=prompt('Shop: 1 Small Potion (12g), 2 Mana Potion (15g), 3 Speed Potion (20g), 4 Defense Potion (20g)');let item=({'1':'Small Potion','2':'Mana Potion','3':'Speed Potion','4':'Defense Potion'})[n],cost=({'1':12,'2':15,'3':20,'4':20})[n];if(!item)return;if(S.gold<cost)return say('Niet genoeg goud.');S.gold-=cost;addItem(item);render()}
function craft(){if((S.bag['Iron Ore']||0)<3||(S.bag['Goblin Ear']||0)<2)return say('Je hebt 3 Iron Ore en 2 Goblin Ear nodig.');S.bag['Iron Ore']-=3;S.bag['Goblin Ear']-=2;S.weapon='Iron Sword';questUpdate('craft','Iron Sword');say('Iron Sword gemaakt en uitgerust.');render()}
function npc(id){if(id==='merchant')return shop();if(id==='blacksmith')return craft();if(id==='healer'){S.hp=S.maxhp;S.mp=S.maxmp;say('Volledig hersteld.');return render()}talk(id)}
function render(){let a=area(),c=classes.find(x=>x[0]===S.cls);$('day').textContent='Dag '+S.day+' · '+String(S.hour).padStart(2,'0')+':00';$('place').textContent=a[1];$('pname').textContent='Wanderer';$('classline').textContent=c[1]+' · '+'★'.repeat(c[3]);$('lvl').textContent='Level '+S.level;$('face').textContent=c[2];$('bars').innerHTML=[['HP',S.hp,S.maxhp,''],['Mana',S.mp,S.maxmp,'mana'],['XP',S.xp,need(),'xp']].map(x=>`<small>${x[0]} ${Math.floor(x[1])}/${x[2]}</small><div class="bar ${x[3]}"><i style="width:${Math.max(0,x[1]/x[2]*100)}%"></i></div>`).join('');$('stats').textContent=`STR ${S.stats.str} · VIT ${S.stats.vit} · AGI ${S.stats.agi} · DEF ${S.stats.def} · INT ${S.stats.int} · ${S.gold} goud · ${S.points} punten`;$('enemyname').textContent=S.enemy?S.enemy.name:'Geen vijand';$('enemy').innerHTML=S.enemy?`${S.enemy.emoji} Lv.${S.enemy.level}<div class="bar"><i style="width:${Math.max(0,S.enemy.hp/S.enemy.max*100)}%"></i></div>${Math.max(0,S.enemy.hp)}/${S.enemy.max} HP`:'Veilig gebied. Verken om een vijand te vinden.';['attack','skill','run'].forEach(id=>$(id).disabled=!S.enemy);$('log').textContent=S.log.join('\\n');view()}
function view(){let v=$('screen');if(tab==='world'){v.innerHTML=`<h2>${area()[2]} ${area()[1]}</h2><p>${area()[4]}</p><div class="map">${areas.map(a=>`<button class="${a[0]===S.area?'here':S.level<a[3]?'locked':''}" onclick="travel('${a[0]}')">${a[2]}<br>${a[1]}<br>Lv.${a[3]}+</button>`).join('')}</div><h3>Gebied</h3><button onclick="spawn()">Verkennen · zoek monster</button><h3>NPC's</h3>${(S.area==='village'?['elder','merchant','blacksmith','trainer','healer']:S.area==='kingdom'?['guild','king','trainer','merchant','blacksmith','healer']:S.area==='harbor'?['harbor']:[]).map(id=>`<div class="tile"><b>${id}</b><button onclick="npc('${id}')">Praten</button></div>`).join('')}`}
if(tab==='quests'){let qx=q();v.innerHTML=`<h2>Quest Journal</h2><p>Hoofdquests voltooid: ${S.completed.length}/${mainQuests.length}</p>${qx?`<div class="quest"><b>${qx[0]}</b><small>${qx[1]}</small><p>Voortgang ${S.progress}/${qx[4]||1}</p></div>`:'Alle hoofdquests afgerond!'}<h3>Voltooid</h3>${S.completed.slice(-10).reverse().map(i=>`<div class="entry">${mainQuests[i][0]}</div>`).join('')}`}
if(tab==='character'){v.innerHTML=`<h2>Klassen & Skill Trees</h2><p>Je klasse levelt mee wanneer je XP verdient. Statpunten: ${S.points}</p>${Object.entries({str:'Strength',vit:'Vitality / HP',agi:'Agility',def:'Defense',int:'Intellect'}).map(([k,n])=>`<div class="row entry">${n}: ${S.stats[k]} <button onclick="spend('${k}')">+1</button></div>`).join('')}<h3>Klassen</h3>${classes.map(c=>`<div class="entry"><div class="row"><b>${c[2]} ${c[1]} · ${c[3]}★</b><button onclick="unlock('${c[0]}')">${S.unlocked.includes(c[0])?'Kiezen':'Vergrendeld'}</button></div><small>${c[4]}</small><small>Klasse level ${S.classLv[c[0]]||1}</small>${c[5].map(s=>`<small>${(S.classLv[c[0]]||1)>=s[1]?'✓':'🔒'} Lv.${s[1]} · ${s[0]} · ${s[2]} mana</small>`).join('')}</div>`).join('')}`}
if(tab==='inventory'){v.innerHTML=`<h2>Inventory & Equipment</h2><div class="entry">Wapen: <b>${S.weapon}</b></div><div class="entry">Pantser: <b>${S.armor}</b></div>${Object.entries(S.bag).map(([n,k])=>`<div class="row entry">${n} × ${k} ${n.includes('Potion')?`<button onclick="potion('${n}')">Gebruiken</button>`:''}</div>`).join('')}<h3>Shop & crafting</h3><button onclick="shop()">Merchant</button> <button onclick="craft()">Blacksmith · Iron Sword</button>`}
if(tab==='journal'){v.innerHTML=`<h2>Adventure Journal · Monster Book</h2><p>Monsters verslagen: ${Object.values(S.kills).reduce((x,y)=>x+y,0)}</p><p>Ontdekte gebieden: ${areas.filter(a=>a[0]===S.area||S.flags['seen_'+a[0]]).length}</p>${monsters.map(m=>`<div class="entry">${m[2]} <b>${m[1]}</b><small>Level ${m[3]} · HP ${m[4]} · Damage ${m[5]} · Respawn ${m[9]} sec · Drops ${m[10].join(', ')}</small></div>`).join('')}`}}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===b));view()});
$('attack').onclick=()=>attack();$('skill').onclick=()=>skill();$('potion').onclick=()=>potion('Small Potion');$('run').onclick=()=>{S.enemy=null;say('Je bent gevlucht.');render()};$('save').onclick=()=>{localStorage.setItem(KEY,JSON.stringify(S));say('Opgeslagen op dit apparaat.')};
render();